For proper function of the program, there is a single dependency that must be install, which is the Pmw 
The directory structure most all so be maintain or else exception will be raised.
Lastly to run the program, run the interface script as it has the binding and access to the rest of the program
To run the script from command line, key the following command
python3 interface.py


The 3 attach to the python is to different python version 2 from 3 which are mostly available in linux system.
